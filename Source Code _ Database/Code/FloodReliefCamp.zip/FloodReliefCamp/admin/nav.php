 <header id="header" class="header">

            <div class="header-menu">

                <div class="col-12">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                       

                       

                    
                

            
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <div class="icon-container">
                                    <span class="ti-power-off"></span><span class="icon-name"></span>
                                </div>
                        </a>

                        <div class="user-menu dropdown-menu">
                           
                            <a class="nav-link" href="profile.php"><i class="fa fa-user"></i> Profile</a>
                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>

                </div> 

                
            </div>

        </header>